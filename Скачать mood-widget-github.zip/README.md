# Mood Widget for GitHub Pages

Published as a static page for iframe integration.